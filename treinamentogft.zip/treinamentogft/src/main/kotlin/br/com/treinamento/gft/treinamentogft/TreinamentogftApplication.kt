package br.com.treinamento.gft.treinamentogft

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TreinamentogftApplication

fun main(args: Array<String>) {
	runApplication<TreinamentogftApplication>(*args)
}
