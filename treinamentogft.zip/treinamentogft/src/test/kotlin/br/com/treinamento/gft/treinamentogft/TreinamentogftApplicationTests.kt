package br.com.treinamento.gft.treinamentogft

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TreinamentogftApplicationTests {

	@Test
	fun contextLoads() {
	}

}
